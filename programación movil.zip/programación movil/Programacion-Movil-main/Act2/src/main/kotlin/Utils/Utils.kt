package Utils

fun readInt() =readLine()?.toInt() ?: 0