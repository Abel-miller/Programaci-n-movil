import Vista.menu

fun main( ) {
    menu()
}