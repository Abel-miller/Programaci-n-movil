package Modelo.Vehiculo

interface Vehiculo {
    fun acelerar()
}
