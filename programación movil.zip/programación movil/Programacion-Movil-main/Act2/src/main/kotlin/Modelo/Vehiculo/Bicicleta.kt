package Modelo.Vehiculo

class Bicicleta : Vehiculo {
    override fun acelerar() {
        println("La bicicleta está acelerando.")
    }
}
