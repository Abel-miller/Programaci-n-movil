package Modelo.Vehiculo

class Coche : Vehiculo {
    override fun acelerar() {
        println("El coche está acelerando.")
    }
}